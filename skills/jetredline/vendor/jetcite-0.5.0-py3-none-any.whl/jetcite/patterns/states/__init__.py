"""State-specific pattern modules."""
